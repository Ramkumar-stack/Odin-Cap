from flask import Blueprint, current_app, request,render_template
import random
import time
import smtplib
from email.mime.text import MIMEText
import re
import string
import firebase_admin
from firebase_admin import credentials, db


bp = Blueprint('main', __name__)

#otp_store = {}  # Stores OTP and timestamp #This is dictionary object - Assuming this is risk of losing if the server crashes, used DB logic
#retry_store = {}  # Stores retry counts

#Load firedb database Example:https://console.firebase.google.com/project/otp-s9034/database/otp-s9034-default-rtdb/data
#Load credentials
firecred=current_app.config['FIRE_CREDENT']
firedb=current_app.config['FIRE_DB']
# Initialize Firebase Admin SDK
cred = credentials.Certificate(firecred)  # Replace with the path to your JSON file
firebase_admin.initialize_app(cred, {
    'databaseURL':firedb  # Replace with your Firebase Realtime Database URL
})


# Function to retrieve OTP from Firebase
def get_otp_from_firebase(email):
    encoded_email = encode_email_for_firebase(email)
    ref = db.reference(f'/otps/{encoded_email}')
    return ref.get()

# Function to delete OTP from Firebase
def delete_otp_from_firebase(email):
    encoded_email = encode_email_for_firebase(email)
    ref = db.reference(f'/otps/{encoded_email}')
    ref.delete()
    

# Function to store OTP in Firebase
def store_otp_in_firebase(email, otp):
    encoded_email = encode_email_for_firebase(email)
    print(encoded_email)
    ref = db.reference(f'/otps/{encoded_email}')
    ref.set({
        'otp': otp,
        'timestamp': time.time(),
        'attempts': 0  # Initialize retry attempts
    })
    
# Function to encode email for Firebase key
def encode_email_for_firebase(email):
    return email.replace('.', ',').replace('@', '_')


# Function to validate email format
def is_valid_email(email):
    pattern = r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email)

# Function to send OTP via email
def send_otp_email(email, otp):
    sender_email=current_app.config['MAIL_USERNAME']
    sender_password=current_app.config['MAIL_PASSWORD']
    subject = "Your OTP Code S9034 App"
    body = f"Your OTP for S9034 App is {otp}. Please use this code to verify your identity. This is valid only for 2 minutes"
    print(body)
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = email

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, email, msg.as_string())
            print(email)
    except smtplib.SMTPException as e:
        return f"SMTP error: {e}"
    except Exception as e:
        return str(e)
    return None

#OTP generation logic
def generate_otp(length=6):
 #return random.randint(100000, 999999)
 # Create a pool of characters
 characters = string.ascii_uppercase + string.ascii_lowercase + string.digits
 # Generate a random string of the given length
 return ''.join(random.choice(characters) for _ in range(length))


#Handle OTP request and send OTP email.
@bp.route('/', methods=['GET', 'POST'])
def send_otp():
   
    if request.method == 'POST':
      
        email = request.form.get('email', '')

        if not is_valid_email(email):
            return render_template('index.html', message="Invalid email address. Please enter a valid email.", otp_sent=False, email=email)

        otp = generate_otp()
        # otp_store[email] = (otp, time.time())
        
        print(otp,'Generated')
        error = send_otp_email(email, otp)
        if error:
            return render_template('index.html', message=f"Failed to send OTP: {error}", email=email)

        try:
            store_otp_in_firebase(email, otp)
        except Exception as e:
            print(str(e))
            return render_template('index.html', message=f"Failed to send OTP: {str(e)}", email=email)

        print(f"OTP stored for {email}: {otp}")

        
        return render_template('index.html', message=f"OTP sent to {email}.", otp_sent=True, email=email)

    return render_template('index.html')

# """Handle OTP verification."""
@bp.route('/verify', methods=['POST'])
def verify_otp():
    email = request.form.get('email', '')
    user_otp = request.form.get('otp', '')
    print(f"Verifying OTP for {email}: {user_otp}")
    otp_data = get_otp_from_firebase(email)

    if otp_data:
        stored_otp = otp_data['otp']
        timestamp = otp_data['timestamp']
        attempts = otp_data['attempts']

    #retry_store[email] = retry_store.get(email, 0)
    #if email in otp_store:
        #stored_otp, timestamp = otp_store[email]
        #print(f"Stored OTP for {email}: {stored_otp}")
    
    # if the verification time took more than 2 minutes, throw error maximum limit reached
    if time.time() - timestamp > 120:
            #del otp_store[email]
            delete_otp_from_firebase(email)
            return render_template('index.html', message="Maximum retry limit reached. Please request a new OTP.", otp_sent=False, email=email)
    
    # if the verification time took more than 2 minutes, throw error maximum limit reached
    if attempts >= 4:
        try:
            delete_otp_from_firebase(email)
        except Exception as e:
            print(str(e))
            return render_template('index.html', message=f"Failed to Verify OTP: {str(e)}", email=email)
        return render_template('index.html', message="Invalid OTP. Too many attempts. Please request OTP again ..", otp_sent=True, email=email)

    # if the verification sucessfully validated, then delete the otp from database and render the page to the valid page.
    if str(stored_otp) == user_otp:
        #del otp_store[email]
        try:
            delete_otp_from_firebase(email)
        except Exception as e:
            print(str(e))
            return render_template('index.html', message=f"Failed to Verify OTP: {str(e)}", email=email)

        return render_template('index.html', message="OTP Verified successfully!<br><br> <a href='https://www.odinschool.com' class='link'>Click here to Odin School</a>", otp_verify=True,otp_sent=False, email=email)
    else:
        encoded_email = encode_email_for_firebase(email)
        try:
            db.reference(f'/otps/{encoded_email}').update({'attempts': attempts + 1})
        except Exception as e:
            print(str(e))
            return render_template('index.html', message=f"Failed to Verify OTP: {str(e)}", email=email)
        
        return render_template('index.html', message="Invalid OTP. Please try again.", otp_sent=True, email=email)

    return render_template('index.html', message="Invalid OTP. Please try again.", otp_sent=True, email=email)
