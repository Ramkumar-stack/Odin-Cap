  // Function to start a countdown timer for resending OTP
function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
   
    var interval = setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = "Retry Request OTP after " + minutes + ":" + seconds;

        if (--timer < 0) {
            clearInterval(interval);
            display.textContent = "Retry Request OTP";
            document.getElementById("sendButton").disabled = false;
            document.getElementById("emailid").disabled = false;
            localStorage.removeItem("timerEndTime");
        }
    }, 1000);
}
 // Function to start a countdown timer for OTP verification
function startTimerverify(duration, display1) {
    var timer = duration, minutes, seconds;
    var interval = setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display1.textContent = "Time Left " + minutes + ":" + seconds;

        if (--timer < 0) {
            clearInterval(interval);
            display1.textContent = "Time elapsed..";
            document.getElementById("submitbutton").disabled = true;
            localStorage.removeItem("timeverifyEndTime");
        }
    }, 1000);
}

// Function to initialize timers on page load
window.onload = function() {
    var timerEndTime = localStorage.getItem("timerEndTime");
    if (timerEndTime) {
        var timeLeft = Math.floor((timerEndTime - new Date().getTime()) / 1000);
        if (timeLeft > 0) {
            document.getElementById("sendButton").disabled = true;
            document.getElementById("emailid").disabled = true;
            startTimer(timeLeft, document.querySelector('#timerLabel'));
        } else {
            localStorage.removeItem("timerEndTime");
        }
    }
    // Check and initialize OTP verification timer
    var timeverifyEndTime = localStorage.getItem("timeverifyEndTime");
    if (timeverifyEndTime) {
        var timeLeft1 = Math.floor((timeverifyEndTime - new Date().getTime()) / 1000);
        if (timeLeft1 > 0) {
            document.getElementById("submitbutton").enabled = true;
            startTimerverify(timeLeft1, document.querySelector('#VerifytimerLabel'));
        } else {
            localStorage.removeItem("timeverifyEndTime");
        }
    }
};

 // Function to start timers for sending and verifying OTP
function initiateTimer() {
    var twoMinutes = 15;
    var now = new Date().getTime();
    var timerEndTime = now + twoMinutes * 1000;
    localStorage.setItem("timerEndTime", timerEndTime);
    startTimer(twoMinutes, document.querySelector('#timerLabel'));

    var verifyitime = 120;
    var now1 = new Date().getTime();
    var timeverifyEndTime = now1 + verifyitime * 1000;
    localStorage.setItem("timeverifyEndTime", timeverifyEndTime);
    startTimerverify(verifyitime, document.querySelector('#VerifytimerLabel'));
}

// Function to validate email format
function isValidEmail(email) {
    var pattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return pattern.test(email);
}

// Function to validate email and start timer
function validateAndSubmit() {
    var email = document.getElementById('emailid').value;

    if (isValidEmail(email)) {
        initiateTimer();  // Call the timer function only if email is valid
        return true;  // Allow form submission
    } else {
        alert("Invalid email address. Please enter a valid email.");
        return false;  // Prevent form submission
    }
}
