from flask import Flask
import configparser

def create_app():
    print('inside the create app.....')
    app = Flask(__name__)
    app.secret_key = 'your_secret_key'

    # Load configuration from a file
    config = configparser.ConfigParser()
    config.read('config.ini')
    app.config['MAIL_USERNAME'] = config.get('EMAIL', 'USER')
    app.config['MAIL_PASSWORD'] = config.get('EMAIL', 'PASS')
    app.config['FIRE_CREDENT'] = config.get('EMAIL', 'FIRECRED')
    app.config['FIRE_DB'] = config.get('EMAIL', 'FIREDB')
 
    # Import and register routes
   
    with app.app_context():
        from . import routes  # Import routes inside the application context
    #from . import routes
    app.register_blueprint(routes.bp)  # if you use Blueprints

    return app