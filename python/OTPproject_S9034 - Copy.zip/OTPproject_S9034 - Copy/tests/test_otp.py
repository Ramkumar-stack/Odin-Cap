import pytest
from flask import Flask
from app import create_app
#from app import create_app

@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True

    with app.test_client() as client:
        yield client

def test_send_otp_valid_email(client):
    response = client.post('/', data={'email': 'test@example.com'})
    assert response.status_code == 200
    assert b'OTP sent to test@example.com.' in response.data

def test_send_otp_invalid_email(client):
    response = client.post('/', data={'email': 'invalid-email'})
    assert response.status_code == 200
    assert b'Invalid email address. Please enter a valid email.' in response.data

def test_verify_otp_correct(client):
    # First, send an OTP
    client.post('/', data={'email': 'test@example.com'})
    
    # Assume OTP 123456 was sent
    response = client.post('/verify', data={'email': 'test@example.com', 'otp': '123456'})
    assert response.status_code == 200
    
    #assert b'200 OK' in response.data
   

def test_verify_otp_incorrect(client):
    # First, send an OTP
    client.post('/', data={'email': 'test@example.com'})
    
    # Use an incorrect OTP
    response = client.post('/verify', data={'email': 'test@example.com', 'otp': '000000'})
    assert response.status_code == 200
    assert b'Invalid OTP. Please try again.' in response.data
