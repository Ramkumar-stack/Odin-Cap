from flask import Blueprint, current_app, request,render_template
import random
import time
import smtplib
from email.mime.text import MIMEText
import re
import string

bp = Blueprint('main', __name__)

otp_store = {}
# Function to validate email format
def is_valid_email(email):
    pattern = r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email)

# Function to send OTP via email
def send_otp_email(email, otp):
    sender_email=current_app.config['MAIL_USERNAME']
    sender_password=current_app.config['MAIL_PASSWORD']
    subject = "Your OTP Code"
    body = f"Your OTP is {otp}. Please use this code to verify your identity."

    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = email

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, email, msg.as_string())
    except smtplib.SMTPException as e:
        return f"SMTP error: {e}"
    except Exception as e:
        return str(e)
    return None

#OTP generation logic
def generate_otp(length=6):
 #return random.randint(100000, 999999)
 # Create a pool of characters
 characters = string.ascii_uppercase + string.ascii_lowercase + string.digits
 # Generate a random string of the given length
 return ''.join(random.choice(characters) for _ in range(length))


#Handle OTP request and send OTP email.
@bp.route('/', methods=['GET', 'POST'])
def send_otp():
   
    if request.method == 'POST':
        email = request.form.get('email', '')

        if not is_valid_email(email):
            return render_template('index.html', message="Invalid email address. Please enter a valid email.", otp_sent=False, email=email)

        otp = generate_otp()
        otp_store[email] = (otp, time.time())
        print(f"OTP stored for {email}: {otp}")

        error = send_otp_email(email, otp)
        if error:
            return render_template('index.html', message=f"Failed to send OTP: {error}", email=email)

        return render_template('index.html', message=f"OTP sent to {email}.", otp_sent=True, email=email)

    return render_template('index.html')

# """Handle OTP verification."""
@bp.route('/verify', methods=['POST'])
def verify_otp():
    email = request.form.get('email', '')
    user_otp = request.form.get('otp', '')
    print(f"Verifying OTP for {email}: {user_otp}")

    if email in otp_store:
        stored_otp, timestamp = otp_store[email]
        print(f"Stored OTP for {email}: {stored_otp}")

        if time.time() - timestamp > 120:
            del otp_store[email]
            return render_template('index.html', message="OTP expired. Please request a new OTP.", otp_sent=False, email=email)

        if str(stored_otp) == user_otp:
            del otp_store[email]
            return render_template('index.html', message="OTP Verified successfully!<br><br> <a href='https://www.odinschool.com' class='link'>Click here to Odin School</a>", otp_verify=True, otp_sent=False, email=email)

    return render_template('index.html', message="Invalid OTP. Please try again.", otp_sent=True, email=email)
