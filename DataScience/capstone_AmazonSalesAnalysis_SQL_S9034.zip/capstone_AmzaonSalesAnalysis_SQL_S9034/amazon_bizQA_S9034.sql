use amazon_data;
/*-- What is the count of distinct cities in the dataset?

select distinct city from amazontable;*/

-- For each branch, what is the corresponding city?
select distinct branch,city from amazontable;

-- What is the count of distinct product lines in the dataset?
select count(distinct productline) from amazontable;

-- Which payment method occurs most frequently?
select paymentType ,count(paymentType) as freq from amazontable group by paymentType order by freq desc limit 1;
WITH PaymentFrequency AS (
    SELECT paymentType,
           COUNT(*) AS freq,
           ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC) AS rn
    FROM amazontable
    GROUP BY paymentType
)
SELECT paymentType, freq
FROM PaymentFrequency
WHERE rn = 1;

-- Which product line has the highest sales?
select round(sum(total),2) as totalsales,productline from amazontable  group by productline order by totalsales desc limit 1;


-- How much revenue is generated each month?

select salesmonthname,round(sum(grossincome),2) as revenue from amazontable group by salesmonthname order by revenue desc;

-- In which month did the cost of goods sold reach its peak?
select salesmonthname,round(sum(cogs),2) as cost from amazontable group by salesmonthname order by cost desc ;


-- Which product line generated the highest revenue?
select productline,round(sum(grossincome),2) as rev from amazontable group by productline order by rev desc;

-- In which city was the highest revenue recorded?
select city , sum(grossincome) as rev from amazontable group by city order by rev desc;

-- Which product line incurred the highest Value Added Tax?
select productline,round(sum(tax5per),2) tax from amazontable group by productline order by tax desc limit 1;


-- For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."

-- select round(avg(total),2) avgsales from amazontable

select    `amazontable`.`Productline`,
    `amazontable`.`Total`,
    CASE
        WHEN `amazontable`.`Total` > (SELECT AVG(`Total`) FROM `amazontable`) THEN 'Good'
        ELSE 'Bad'
    END as SalesQuality
from 
    `amazontable`;


-- Identify the branch that exceeded the average number of products sold.

with BranchSales AS (
    SELECT 
        Branch,
        SUM(Quantity) AS TotalProductsSold
    FROM 
        amazontable
    GROUP BY 
        Branch
),
AverageSales AS (
    select 
        AVG(TotalProductsSold) AS AvgProductsSold
    FROM 
        BranchSales
)
select 
    Branch,
    TotalProductsSold
FROM 
    BranchSales
WHERE 
    TotalProductsSold > (SELECT AvgProductsSold FROM AverageSales);


-- Which product line is most frequently associated with each gender?
-- select productline,gender from amazontable;
 with ProductLineFrequency AS (
    SELECT 
        Gender,
        Productline,
        COUNT(*) AS Frequency,
        ROW_NUMBER() OVER (PARTITION BY Gender ORDER BY COUNT(*) DESC) AS rn
    from 
        amazontable
    group by 
        Gender, Productline
)
select 
    Gender,
    Productline,
    Frequency
from 
    ProductLineFrequency
where 
    rn = 1;


-- Calculate the average rating for each product line.
select productline,round(avg(rating),2) from amazontable group by productline;


-- Count the sales occurrences for each time of day on every weekday

select 
    salesdayname AS Weekday,
    timeofday AS TimeOfDay,
    COUNT(*) AS SalesOccurrences
from  
    amazontable
GROUP BY 
    salesdayname, 
    timeofday
ORDER BY 
    salesdayname, 
    timeofday;

-- Identify the customer type contributing the highest revenue.
select customertype , sum(grossincome) as rev from amazontable group by customertype order by rev desc limit 1 ;


-- Determine the city with the highest VAT percentage.
select city, max(tax5per) as vat from amazontable group by city order by vat desc limit 1;


-- Identify the customer type with the highest VAT payments.
select customertype,sum(tax5per) as vat from amazontable group by customertype order by vat desc limit 1;



-- What is the count of distinct customer types in the dataset?
select count(distinct customertype) from amazontable;
-- What is the count of distinct payment methods in the dataset?
select distinct paymenttype from amazontable;


-- Which customer type occurs most frequently?
select customertype,count(*) as count1 from amazontable group by customertype order by count1 desc;


 -- Identify the customer type with the highest purchase frequency.
select customertype,count(*) as purchasecount from amazontable group by customertype order by purchasecount desc;

 
 -- Determine the predominant gender among customers.
 select gender,count(*) as count1 from amazontable group by gender order by count1 desc;
 
 -- Examine the distribution of genders within each branch.
  select branch,gender,count(*) as count1 from amazontable group by branch,gender order by branch,gender;
 
  -- Identify the time of day when customers provide the most ratings.
  select timeofday,count(rating) as rating_count from amazontable group by timeofday order by  rating_count DESC;
  
  
  -- Determine the time of day with the highest customer ratings for each branch.
  -- select branch,timeofday,max(rating) as maxrate from amazontable group by branch,timeofday order by maxrate;
  WITH BranchMaxRatings AS (
    SELECT
        branch,
        timeofday,
        MAX(rating) AS max_rate
    FROM
        amazontable
    GROUP BY
        branch,
        timeofday
),
BranchHighestRatings AS (
    SELECT
        branch,
        MAX(max_rate) AS highest_rating
    FROM
        BranchMaxRatings
    GROUP BY
        branch
)
SELECT
    b.branch,
    b.timeofday,
    b.max_rate AS max_rating
FROM
    BranchMaxRatings b
JOIN
    BranchHighestRatings h
ON
    b.branch = h.branch
    AND b.max_rate = h.highest_rating
ORDER BY
    b.branch;
    

    

    -- Identify the day of the week with the highest average ratings.
select
    salesdayname,
    AVG(rating) AS avg_rating
from
    amazontable
GROUP BY
    salesdayname
ORDER BY
    avg_rating DESC
LIMIT 1;    

-- Determine the day of the week with the highest average ratings for each branch.
with branchavgrate as(
select branch,salesdayname,avg(rating) as avgrate from amazontable group by branch,salesdayname),
branchmaxrate as( 
select branch,max(avgrate) as highestrating from branchavgrate group by branch)
SELECT
    b.branch,
    b.salesdayname,
    b.avgrate AS avg_rate
FROM
    branchavgrate b
JOIN
    branchmaxrate h
ON
    b.branch = h.branch
    AND b.avgrate = h.highestrating
ORDER BY
    b.branch;

