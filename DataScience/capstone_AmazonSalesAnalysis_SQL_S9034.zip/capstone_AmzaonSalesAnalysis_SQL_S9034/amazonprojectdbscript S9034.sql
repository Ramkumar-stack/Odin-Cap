-- create schema amazon_data;
use amazon_data;
/* DROP TABLE IF EXISTS amazontable;

CREATE TABLE `amazontable` (
  `InvoiceID` Varchar(11) Primary key,
  `Branch` Varchar(1),
  `City` varchar(9),
  `Customertype` varchar(6),
  `Gender` varchar(6),
  `Productline` varchar(22),
  `Unitprice` double DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  `Tax5per` double DEFAULT NULL,
  `Total` double DEFAULT NULL,
  `InvDate` Date,
  `InvTime` Time,
  `PaymentType` varchar(11),
  `cogs` double DEFAULT NULL,
  `grossmarginpercentage` double DEFAULT NULL,
  `grossincome` double DEFAULT NULL,
  `Rating` double DEFAULT NULL);

select count(*) from amazontable 

-- add new timeofday column with Morning,Evening,Afternoon based on the time
alter table amazontable add column timeofday varchar(10);
UPDATE amazontable
SET timeofday = CASE
    WHEN TIME(invtime) BETWEEN '06:00:00' AND '11:59:59' THEN 'Morning'
    WHEN TIME(invtime) BETWEEN '12:00:00' AND '17:59:59' THEN 'Afternoon'
    ELSE 'Evening'
END; 

select invdate,invtime,timeofday from amazontable;

-- Add a new column named dayname that contains the extracted days of the week on which the given transaction took place (Mon, Tue, Wed, Thur, Fri). This will help answer the question on which week of the day each branch is busiest.
alter table amazontable add column salesdayname varchar(4);

update amazontable set salesdayname=date_format(invdate,'%a');
select invdate,invtime,salesdayname from amazontable;

-- Add a new column named monthname that contains the extracted months of the year on which the given transaction took place (Jan, Feb, Mar). Help determine which month of the year has the most sales and profit.
alter table amazontable add column salesmonthname varchar(4);

update amazontable set salesmonthname=date_format(invdate,'%b');
select invdate,invtime,salesdayname,salesmonthname from amazontable; */


-- Calculate mean and standard deviation
SELECT 
    AVG(`Tax5per`) AS mean_total,
    STDDEV(`Tax5per`) AS stddev_total
INTO @mean, @stddev
FROM 
    amazontable;

-- Identify outliers using Z-score
SELECT *,
       (`Tax5per` - @mean) / @stddev AS z_score
FROM 
    amazontable
HAVING 
    ABS(z_score) > 3;
